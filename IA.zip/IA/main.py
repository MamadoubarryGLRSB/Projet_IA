import numpy as np
from scipy.stats import wilcoxon, kruskal
from mealpy import PSO, DE, GWO
from mealpy.utils.space import FloatVar
from mealpy.utils.problem import Problem 


# Fonction de Rosenbrock
def rosenbrock(solution):
    dimension = len(solution)
    return sum(100.0 * (solution[i+1] - solution[i]**2)**2 + (1 - solution[i])**2 for i in range(dimension-1))

# Paramètres communs pour tous les algorithmes
parametres_algorithme = {
    "epoch": 100,
    "pop_size": 30,
    "c1": 2.05,
    "c2": 3.0,
    "w": 0.4,
}

# Définissez le nombre d'exécutions
nombre_executions = 20,

# Problème commun à tous les algorithmes
probleme = Problem(
    bounds=[FloatVar(-10., 10.) for _ in range(30)],
    obj_func=rosenbrock,
    minmax="min",
)

# Stockez les résultats pour chaque algorithme
resultats = {}

algorithmes = {
    'PSO': PSO.OriginalPSO,
    'DE': DE.OriginalDE,
    'GWO': GWO.OriginalGWO,
}

# Exécutez vos algorithmes
for nom_algorithme, algorithme in algorithmes.items():
    print(f"\nExécution de {nom_algorithme} pour la fonction de Rosenbrock")
    resultats[nom_algorithme] = []
    for _ in range(nombre_executions):
        model = algorithme(**parametres_algorithme)
        g_best = model.solve(probleme)
        resultats[nom_algorithme].append(g_best.target.fitness)

# Imprimez les résultats
for nom_algorithme, resultat in resultats.items():
    moyenne, ecart_type = np.mean(resultat), np.std(resultat)
    print(f"{nom_algorithme} - Moyenne: {moyenne}, Écart type: {ecart_type}")

# Effectuez des tests statistiques (par exemple, test de Wilcoxon)
for algo1, algo2 in [('PSO', 'DE'), ('PSO', 'GWO'), ('DE', 'GWO')]:
    print(f"\nTest de Wilcoxon entre {algo1} et {algo2}")
    _, p_value = wilcoxon(resultats[algo1], resultats[algo2])
    print(f"Valeur p de Wilcoxon ({algo1} vs {algo2}): {p_value}")

# Vous pouvez également utiliser le test de Kruskal-Wallis pour comparer les trois algorithmes simultanément
print("\nTest de Kruskal-Wallis pour tous les algorithmes")
_, p_value_kruskal = kruskal(resultats['PSO'], resultats['DE'], resultats['GWO'])
print(f"Valeur p de Kruskal-Wallis: {p_value_kruskal}")
